package com.service;

import com.model.Registration;

public interface RegistrationService {
	public void add(Registration registration);
}
