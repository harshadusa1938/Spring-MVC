Title: Spring MVC Hibernate Sample Application (With Spring &amp; Hib 3 Release)
Description: Its a complete application with proper data structure for beginners who have passion to use spring mvc and hibernate for performing operations like validation,crud activity,transaction settings,logging settings,etc with spring framework. I have used latest releases of spring 3.x and hibernate 3.x.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6475&lngWId=2

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
